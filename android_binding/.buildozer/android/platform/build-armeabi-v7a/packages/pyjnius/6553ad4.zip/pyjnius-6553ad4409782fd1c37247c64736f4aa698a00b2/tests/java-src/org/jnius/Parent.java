package org.jnius;

public class Parent {
	static public Parent newInstance(){
		return new Parent();
	}
}
